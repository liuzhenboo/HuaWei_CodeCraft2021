#ifndef HWCODECRAFT2021_OFFLINEJUDGER_H
#define HWCODECRAFT2021_OFFLINEJUDGER_H

#include "data_type.h"

void runJudger(std::string inputFile,std::string outputFile);

#endif //HWCODECRAFT2021_OFFLINEJUDGER_H
